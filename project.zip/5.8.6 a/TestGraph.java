import java.awt.*;
import javax.swing.*;
import java.awt.geom.Line2D;

public class TestGraph {
 public static void main(String[] a) {
  BarGraphWriter e = new BarGraphWriter();
  e.setTitle("Days in first four months of the year");
  e.setAxes(20, 120, "30", 90); // x- and y-axes start at  20, 120
  // graph is 90 pixels high; top of graph is labelled "30"
  int scale_factor = 3;
  e.setBar1("Jan", 31 * scale_factor, Color.red); // Jan has 31 days
  e.setBar2("Feb", 28 * scale_factor, Color.white); // etc.
  e.setBar3("Mar", 31 * scale_factor, Color.blue);
  e.setBar4("Apr", 30 * scale_factor, Color.yellow);
 }
}

class BarGraphWriter extends JPanel {
 private int width = 600;
 private int height = width/2;
 
 private int barWidth = width/10;
 private int barHeight = height/5;

 private String topLabel;
 private String bottomLabel = "0";
 
 private int axisHeight;
 private int initAxisHeight;
 

 private int x_pos;
 private int initX; // initial x coordinate
 private int y_pos;
 private int initY; // initial x coordinate

 Bar bar1;
 Bar bar2;
 Bar bar3;
 Bar bar4;
 Bar bar5;
 Bar bar6;
 JFrame frame;


 public BarGraphWriter() {

  this.setBackground(new Color(204, 238, 255));
  frame = new JFrame();
  frame.getContentPane().add(this);
  frame.setSize(width, height);
  frame.setVisible(true);

 }
 
 public void paintComponent(Graphics g){
 

  
  barWidth = frame.getWidth() / 10;
  barHeight = frame.getHeight() / 5;
  
  x_pos = initX;
  y_pos = initY;
  axisHeight = initAxisHeight;
  
  y_pos += barHeight;
  axisHeight += barHeight;
  
  if(bar1 != null){
   paintBar(bar1, g);
  }
  
  if(bar2 != null){
   paintBar(bar2, g);
  }
 
  if(bar3 != null){
   paintBar(bar3, g);
  }
  
  if(bar4 != null){
   paintBar(bar4, g);
  }
 
  if(bar5 != null){
   paintBar(bar5, g);
  }
  
  if(bar6 != null){
   paintBar(bar6, g);
  }
  
   // draw line
  
   g.setColor(Color.BLACK);
   
   // x-axis
   g.drawLine(initX-5, y_pos, initX-5 + x_pos-5, y_pos);
   
   // y-axis
   g.drawLine(initX-5, y_pos, initX-5, (y_pos -axisHeight));
   
   // top label
   g.drawString(topLabel, 0, (y_pos - axisHeight));
   
   // bottom label (0)
   g.drawString("0", 3, y_pos);
 
 }
 
 private void paintBar(Bar bar, Graphics g){
 
  // sh for shadow
  // shadow bar coordinates, width and height
  int shX = x_pos+3;
  int shY = y_pos+3;
  int shW = barWidth;
  int shH = (bar.height-3)+barHeight;
  
  //draw shadow bar
  g.setColor(Color.BLACK);
  g.fillRect(shX, shY - shH, shW, shH);
  g.drawRect(shX, shY - shH, shW, shH);
 
 // bar coordinates, width and height
  int X = x_pos;
  int Y = y_pos;
  int W = barWidth;
  int H = bar.height+barHeight;
 
  //draw bar 
  g.drawString(bar.label, X, Y + 20);
  g.setColor(bar.color);
  g.fillRect(X, Y - H, W, H);
  g.setColor(Color.BLACK);
  g.drawRect(X, Y - H, W, H);
  
//   System.out.println("x: "+X+" y: "+ Y);
//   System.out.println("shX: "+shX+" shY: "+ shY);
//   System.out.println("bar height: "+H);
  
  x_pos += barWidth + 15;
  
 }

 public void setTitle(String title) {
  frame.setTitle(title);
 }

 public void setAxes(int x_pos, int y_pos, String top_label, int y_height) {

  this.x_pos = x_pos;
  this.initX = x_pos;
  this.y_pos = y_pos;
  this.initY = y_pos;
  this.topLabel = top_label;
  this.axisHeight = y_height;
  this.initAxisHeight = y_height;

  this.repaint();

 }


 public void setBar1(String label, int height, Color c) {
  bar1 = new Bar(label, height, c);
  this.repaint();

 }

 public void setBar2(String label, int height, Color c) {
  bar2 = new Bar(label, height, c);
  this.repaint();

 }

 public void setBar3(String label, int height, Color c) {
  bar3 = new Bar(label, height, c);
  this.repaint();

 }

 public void setBar4(String label, int height, Color c) {
  bar4 = new Bar(label, height, c);
  this.repaint();
 }

 public void setBar5(String label, int height, Color c) {
  bar5 = new Bar(label, height, c);
  this.repaint();
 }

 public void setBar6(String label, int height, Color c) {
  bar6 = new Bar(label, height, c);
  this.repaint();
 }

}

class Bar {
 public String label;
 public int height;
 public Color color;


 Bar(String label, int height, Color color) {

  this.label = label;
  this.height = height;
  this.color = color;

 }


}
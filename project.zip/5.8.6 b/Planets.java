import java.awt.*;
import javax.swing.*;
import java.awt.geom.Line2D;

 public class Planets {
 public static void main(String[] a) {
 
  double scale_factor = 2.0;
  
   JFrame frame = new JFrame();
   frame.setSize(900,700);
   frame.setVisible(true);
   frame.setTitle("Interesting statistics about the first six planets:");
  
   BarGraphWriter e = new BarGraphWriter(frame);
   e.setTitle("Distance from Sun(astronomical units)");
  
   e.setAxes("10", 100, 250, 100, scale_factor); 
  
   e.setBar1("Mer",0.387*10, new Color(255, 160, 122), "Mercury  :   0.387"); //Merkuri ka distancen prej diellit 0,387
   e.setBar2("Ven",0.723*10, new Color(233, 150, 122), "Venus  :   0.723"); // etc.
   e.setBar3("Ear",1.00*10, new Color(250, 128, 114), "Earth  :   1.00");
   e.setBar4("Mar",1.524*10, new Color(240, 128, 128), "Mars  :   1.524");
   e.setBar5("Jup",5.203*10, new Color(205, 92, 92), "Jupiter  :   5.203");
   e.setBar6("Sat",9.539*10, new Color(203, 67, 53), "Saturn  :   9.539"); 
   
   
   scale_factor = 0.5;
  
   BarGraphWriter f = new BarGraphWriter(frame);
   f.setTitle("Mass(relative to Earth)");
  
   f.setAxes("400",100,550, 400, scale_factor); 
  
   f.setBar1("Mer",0.05+2, new Color(255, 160, 122), "Mercury  :   0.05"); //Merkuri ka distancen prej diellit 0,387
   f.setBar2("Ven",0.81+2 , new Color(233, 150, 122), "Venus  :   0.81"); // etc.
   f.setBar3("Ear",1.00+2 , new Color(250, 128, 114), "Earth  :   1.00");
   f.setBar4("Mar",0.11+2 , new Color(240, 128, 128), "Mars  :   0.11");
   f.setBar5("Jup",318.4+2 , new Color(205, 92, 92), "Jupiter  :   318.4");
   f.setBar6("Sat",95.3+3, new Color(203, 67, 53), "Saturn  :   95.3"); 

   }
}


class BarGraphWriter extends JPanel {
 private double scale_factor;
 
 private int barWidth;
 private int barHeight;
 
 private int highestValue;

 private String topLabel;
 private String bottomLabel = "0";
 
 private int axisHeight;
 private int initAxisHeight;
 
 private String graphTitle;
 

 private int x_pos;
 private int initX; // initial x coordinate
 private int y_pos;
 private int initY; // initial x coordinate

 Bar bar1;
 Bar bar2;
 Bar bar3;
 Bar bar4;
 Bar bar5;
 Bar bar6;
 JFrame frame;


 public BarGraphWriter(JFrame frameArg) {

  this.setBackground(new Color(204, 238, 255));
  frame = frameArg;
  frame.getContentPane().add(this);
  frame.setVisible(true);
  barWidth = (frame.getWidth())/25;

 }
 
    public void paintComponent(Graphics g){
   
     
     x_pos = initX;
     y_pos = initY;
     axisHeight = initAxisHeight;
   
    
     if(bar1 != null){
      paintBar(bar1, g);
     }
     
     if(bar2 != null){
      paintBar(bar2, g);
     }
    
     if(bar3 != null){
      paintBar(bar3, g);
     }
     
     if(bar4 != null){
      paintBar(bar4, g);
     }
    
     if(bar5 != null){
      paintBar(bar5, g);
     }
     
     if(bar6 != null){
      paintBar(bar6, g);
     }
     
    // draw line
    g.setColor(Color.BLACK);
   
    // x-axis
    g.drawLine(initX-5, y_pos, initX-5 + x_pos-5, y_pos);
   
    // y-axis
    g.drawLine(initX-5, y_pos, initX-5, (y_pos - axisHeight));
    
    // top label
    g.drawString(topLabel, initX-28, (y_pos - axisHeight));
   
    // bottom label (0)
    g.drawString("0", initX-13, y_pos+3);
    
    
    g.drawString(bar1.legend,x_pos+15,y_pos-200);
    g.drawString(bar2.legend,x_pos+15,y_pos-185);
    g.drawString(bar3.legend,x_pos+15,y_pos-170);
    g.drawString(bar4.legend,x_pos+15,y_pos-155);
    g.drawString(bar5.legend,x_pos+15,y_pos-140);
    g.drawString(bar6.legend,x_pos+15,y_pos-125);
    
    g.drawString(graphTitle,x_pos/2,y_pos+50);

     //  
//       System.out.println("y_pos: " + y_pos + " x_pos: " + x_pos);
//       System.out.println("initY: " + initY + " initX: " + initX);
//       System.out.println("axisHeight: " + axisHeight+ " initAxisHeight: " + initAxisHeight);
//       System.out.println("barWidth: " + barWidth + " barHeight: " + barHeight);
   
    
    }
 
 private void paintBar(Bar bar, Graphics g){
 
  // sh for shadow
  // shadow bar coordinates, width and height
  int shX = x_pos+3;
  int shY = y_pos+3;
  int shW = barWidth;
  int shH = (int)((bar.height-3)*scale_factor);
  
  //draw shadow bar
  g.setColor(Color.BLACK);
  g.fillRect(shX, shY - shH, shW, shH);
  g.drawRect(shX, shY - shH, shW, shH);
 
 // bar coordinates, width and height
  int X = x_pos;
  int Y = y_pos;
  int W = barWidth;
  int H = (int)(bar.height *scale_factor);
 
  //draw bar 
  g.drawString(bar.label, X, Y + 20);
  g.setColor(bar.color);
  g.fillRect(X, Y - H, W, H);
  g.setColor(Color.BLACK);
  g.drawRect(X, Y - H, W, H);
  
  System.out.println("x: "+X+" y: "+ Y);
  System.out.println("shX: "+shX+" shY: "+ shY);
  System.out.println("bar height: "+H);
  
  x_pos += barWidth + 10;
  
 }

 public void setTitle(String title) {
  graphTitle = title;
 }

 public void setAxes(String top_label, int x_pos, int y_pos, int highValue, double scale) {
 
  this.scale_factor = scale;
 
  highestValue = highValue;
  topLabel = top_label;
  
  this.x_pos = x_pos;
  this.initX =x_pos;
  
  this.y_pos = y_pos;//(highestValue * scale_factor)+20 ;
  this.initY = this.y_pos;
  this.axisHeight = (int)(highestValue * scale_factor);
  this.initAxisHeight = (int)(highestValue * scale_factor);
  
  
  this.repaint();

 }


 public void setBar1(String label, double height, Color c, String legend) {
  bar1 = new Bar(label, height, c, legend);
  this.repaint();

 }

 public void setBar2(String label, double height, Color c, String legend) {
  bar2 = new Bar(label, height, c, legend);
  this.repaint();

 }

 public void setBar3(String label, double height, Color c, String legend) {
  bar3 = new Bar(label, height, c, legend);
  this.repaint();

 }

 public void setBar4(String label, double height, Color c, String legend) {
  bar4 = new Bar(label, height, c, legend);
  this.repaint();
 }

 public void setBar5(String label, double height, Color c, String legend) {
  bar5 = new Bar(label, height, c, legend);
  this.repaint();
 }

 public void setBar6(String label, double height, Color c, String legend) {
  bar6 = new Bar(label, height, c, legend);
  this.repaint();
 }

}

class Bar {
 public String label;
 public double height;
 public Color color;
 public String legend;


 Bar(String label, double height, Color color, String legend) {

  this.label = label;
  this.height = height;
  this.color = color;
  this.legend = legend;

 }


}